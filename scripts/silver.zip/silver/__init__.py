"""Package marker for silver processing scripts."""
